==================================
What's Ext2Fsd
==================================

The Ext2Fsd project is an ext2 file system driver for WinNT/2000/XP.
It's a free software and everyone can distribute and modify it under
the terms of GNU GPL.

==================================
Author & Homepage
==================================

Matt <mattwu@163.com>
http://www.ext2fsd.com

==================================
Directories of ext2fsd package
==================================

->Setup:
   Setup files and driver binaries for XP/2003/2008/7/8 (i386/AMD64).
   Nt4 is no longer supported.

->Documents
   Help files for Ext2Fsd

->Src
   Source codes of Ext2Fsd / Mke2fs ...


